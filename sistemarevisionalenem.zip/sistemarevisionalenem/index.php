
<style type="text/css">
    body{
        background:#363636;
    }
    .e{
        background:#008c7a;
        text:white;
        border: 1px solid black;
        border-radius: 10px;
        border-style: outset;
        border: gray;

    }
    .e tr:hover{
        background:#00aeff ;
        border-bottom: 30px solid #ddd;
    }
    .materias{
        float:right;
        width:20%;
        height:12%;
        margin-top:0%;
        }
    .titulo{
        color:white;
        text-align:top;
        width:48%;
        height:10%;
        margin-top:0%;
        background:gray;
        background-size:34%;
        }
    
       
    
    .horarios{
        color:red;
        background:white;
        width:48%;
    }

    a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: red;
  background-color: transparent;
  text-decoration: underline;
}
.p{
        color:white;
        height:10%;
}
    </style> 

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>SISTEMA REVISIONAL ENEM</title>
	</head>
<body>
<div class="centro">
<div class="materias">
<table border=3px  class="e">
<tr><td><h2><a href="materias.php">Materiais disponiveis<a><h2></td></tr>
<tr><td></td></tr>
<tr><td><h2><a href="https://chat.whatsapp.com/D0tCw6uhSWPFTL8amkGYnZ">Grupo do Whatsapp<a><h2></td></tr>
<tr><td><h2><a href="login.php">Aulas Gravadas<a><h2></td></tr>


</table>




</div>



<center><div class="titulo"> <H1>SISTEMA REVISIONAL ENEM<H1> </div></center>

<center><div class="horarios"><h1>HORARIOS DOS ENCONTROS(18 A 21/10)</h1>
<table BORDER=2PX >
        <tr>  <td><h1>HORARIOS</h1></td>   <td>SEGUNDA</td>  <td>TERÇA</td>  <td>QUARTA</td> <td>QUINTA</td> </tr>
        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/ywy-nxpm-yan">Orientações da Coordenação<a></td>  <td><a href="https://meet.google.com/owk-hrpk-gad">Linguagens – Gramática </a></td>  <td><a href="https://meet.google.com/mfg-fqbr-oqa">História<a></td> <td><a href="https://meet.google.com/twm-cugj-dru">Linguagens – 
Literatura
<a></td> </tr>

        <tr>  <td><h1>20:00 as 21:00</h1></td>  <td><a href="https://meet.google.com/ywy-nxpm-yan">Filosofia<a></td>  <td><a href="https://meet.google.com/owk-hrpk-gad">Linguagens – Gramática </a></td>  <td><a href="https://meet.google.com/mfg-fqbr-oqa">História<a></td> <td><a href="https://meet.google.com/twm-cugj-dru">Linguagens – 
Literatura
<a></td> </tr>
        
</table>

<h1>HORARIOS DOS ENCONTROS(25 A 28/10)</h1>
<table BORDER=2PX >
        <tr>  <td><h1>HORARIOS</h1></td>   <td>SEGUNDA</td>  <td>TERÇA</td>  <td>QUARTA</td> <td>QUINTA</td> </tr>
        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/iac-brqy-jdf">Geografia<a></td>  <td><a href="https://meet.google.com/bac-mbtc-rms?hs=122&authuser=0">Linguagens –Redação </a></td>  <td><a href="https://meet.google.com/frf-svwt-iif">Sociologia<a></td> <td><a href="https://meet.google.com/xuc-sxam-vfu">Inglês
<a>/<a href="  https://meet.google.com/dun-kncx-znd">Espanhol<a></td> </tr>

<tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/iac-brqy-jdf">Geografia<a></td>  <td><a href="https://meet.google.com/bac-mbtc-rms?hs=122&authuser=0">Linguagens –Redação </a></td>  <td><a href="https://meet.google.com/wkw-hyjd-tzr">Educação Física<a></td> <td><a href="https://meet.google.com/xuc-sxam-vfu">Inglês
<a>/<a href="  https://meet.google.com/dun-kncx-znd">Espanhol<a></td> </tr>
        
</table>

<h1>HORARIOS DOS ENCONTROS(01 A 04/11)</h1>
<table BORDER=2PX >
        <tr>  <td><h1>HORARIOS</h1></td>   <td>SEGUNDA</td>  <td>TERÇA</td>  <td>QUARTA</td> <td>QUINTA</td> </tr>
        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/rup-mvsy-bnh">Matemática<a></td>  <td><a href="https://meet.google.com/gws-qnqa-iaj">Biologia </a></td>  <td><a href="https://meet.google.com/zkj-mhbc-ivd">Química<a></td> <td><a href="https://meet.google.com/dpb-uwvq-sfj">Física
<a></td> </tr>

        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/rup-mvsy-bnh">Matemática<a></td>  <td><a href="https://meet.google.com/gws-qnqa-iaj">Biologia </a></td>  <td><a href="https://meet.google.com/zkj-mhbc-ivd">Química<a></td> <td><a href="https://meet.google.com/dpb-uwvq-sfj">Física
<a></td> </tr>
        
</table>

<h1>HORARIOS DOS ENCONTROS(08 A 11/11)</h1>
<table BORDER=2PX >
        <tr>  <td><h1>HORARIOS</h1></td>   <td>SEGUNDA</td>  <td>TERÇA</td>  <td>QUARTA</td> <td>QUINTA</td> </tr>
        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href=" https://meet.google.com/tao-cofj-wru">Educação Física<a></td>  <td><a href="https://meet.google.com/bac-mbtc-rms?hs=122&authuser=0">Linguagens – Redação </a></td>  <td><a href="https://meet.google.com/sgs-zaqq-qiu">Linguagens – Gramática<a></td> <td><a href="https://meet.google.com/thw-safr-efm">Geografia
<a></td> </tr>

        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href="https://meet.google.com/frf-svwt-iif">Sociologia<a></td>  <td><a href="https://meet.google.com/bac-mbtc-rms?hs=122&authuser=0">Linguagens – Redação </a></td>  <td><a href="https://meet.google.com/jxw-kscr-rii">Linguagens – Literatura<a></td> <td><a href="https://meet.google.com/mfg-fqbr-oqa">História
<a></td> </tr>
        
</table>




<h1>HORARIOS DOS ENCONTROS(15 A 18/11)</h1>
<table BORDER=2PX >
        <tr>  <td><h1>HORARIOS</h1></td>   <td>SEGUNDA</td>  <td>TERÇA</td>  <td>QUARTA</td> <td>QUINTA</td> </tr>
        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href=" https://meet.google.com/gsk-pziy-umo">Física<a></td>  <td><a href="https://meet.google.com/zkj-mhbc-ivd">Química </a></td>  <td><a href="https://meet.google.com/ecy-ucgq-ghx">Biologia<a></td> <td><a href="https://meet.google.com/cqz-xqkq-end">Matemática
<a></td> </tr>

        <tr>  <td><h1>19:00 as 20:00</h1></td>   <td><a href=" https://meet.google.com/gsk-pziy-umo">Física<a></td>  <td><a href="https://meet.google.com/zkj-mhbc-ivd">Química </a></td>  <td><a href="https://meet.google.com/ecy-ucgq-ghx">Biologia<a></td> <td><a href="https://meet.google.com/cqz-xqkq-end">Matemática
<a></td> </tr>
        
</table>



</div>
</center>
<center><footer class="p">
<h3>Copyright 2021© @erikmsouza📩</h3>
</footer></center>
</div>
</body>
</html>
