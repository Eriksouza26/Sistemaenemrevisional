<?php
	$servidor = "fdb32.awardspace.net";
	$usuario = "3967985_enem";
	$senha = "Eriksouza2601";
	$dbname = "3967985_enem";
	

	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
