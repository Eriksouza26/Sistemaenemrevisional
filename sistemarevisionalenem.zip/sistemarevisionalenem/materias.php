<style type="text/css">
    body{
        background:#363636;
    }
    .r{
        background:#008c7a;
        text:white;
        border: 1px solid black;
        border-radius: 10px;
        border-style: outset;
        border: gray;
        width:48%

    }
    .r tr:hover{
        background:# 000000 ;
        border-bottom: 30px solid #ddd;
    }
    .o{
        background-color:white;
        float:right;
        width:11%;
        height:5%;
        margin-right:15%;
        }
    .i{
        color:white;
        text-align:top;
        width:48%;
        height:10%;
        margin-top:0%;
        background:gray;
        background-size:34%;
        }
    
       
    
    .horarios{
        color:red;
        background:white;
        width:48%;
    }

    a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: red;
  background-color: transparent;
  text-decoration: underline;
}
</style> 
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>SISTEMA REVISIONAL ENEM</title>
	</head>
<body>
   <center> <div class="i">
        <h1>MATÉRIAS</h1>
    </div></center>
    <div class="o"> 
        <table>
            <tr><td><a href="index.php"><input type="button" value="VOLTAR AO INICIO"><a></td></tr>
        </table>
    </div>
    
    <center><div class="r">
        <h2>
        <table border=3px>
        <tr>   <td> <H1>Matérias</H1></td>                <td><h1>Professores</h1></td>                                </tr>

        <tr>  <td><a href="filosofia.php">Filosofia</a></td>  <td>Francisco Juceme </td>     </tr>
        <tr>  <td><a href="gramatica.php">Gramatica</a></td>  <td>Robledo Esteves  </td>     </tr>
        <tr>  <td><a href="historia.php">Historia</a></td>  <td>Helvécio Pinto </td>     </tr>
        <tr>  <td><a href="literatura.php">Literatura</a></td>  <td>Roberta Vecchi  </td>     </tr>
        <tr>  <td><a href="geografia.php">Geografia</a></td>  <td>Rafael Santiago/Woton Ribeiro   </td>     </tr>
        <tr>  <td><a href="redacao.php">Redação</a></td>  <td>Claudia Gomes </td>     </tr>
        <tr>  <td><a href="sociologia.php">Sociologia</a></td>  <td>Patrícia Furtado  </td>     </tr>
        <tr>  <td><a href="ingles.php">Inglês</a></td>  <td>Flávia Luciana  </td>     </tr>
        <tr>  <td><a href="espanhol.php">Espanhol</a></td>  <td>Josimar Gonçalves  </td>     </tr>
        <tr>  <td><a href="educafisi.php">Educação Fisica</a></td>  <td>Matheus Santos  </td>     </tr>
        <tr>  <td><a href="matematica.php">Matematica</a></td>  <td>Roberto Alves/Marcelo Cunha/Hernando José/Valter Costa/ </td>     </tr>
        <tr>  <td><a href="biologia.php">Biologia</a></td>  <td>Paulo Bomtempo/Patrizia Mello  </td>     </tr>
        <tr>  <td><a href="quimica.php">Quimica</a></td>  <td>Francisco Frederico  </td>     </tr>
        <tr>  <td><a href="fisica.php">Fisica</a></td>  <td>Wendel Fajardo/Ruy Batista  </td>     </tr>







        </table>
        </h2></center>



    </div>





</body>
</html>