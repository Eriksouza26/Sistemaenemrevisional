<style type="text/css">
    body{
        background:#363636;
    }
    .r{
        background:#008c7a;
        text:white;
        border: 1px solid black;
        border-radius: 10px;
        border-style: outset;
        border: gray;
        width:48%

    }
    .r tr:hover{
        background:# 000000 ;
        border-bottom: 30px solid #ddd;
    }
    .o{
        background-color:white;
        float:right;
        width:12%;
        height:5%;
        margin-right:15%;
        }
    .i{
        color:white;
        text-align:top;
        width:48%;
        height:10%;
        margin-top:0%;
        background:gray;
        background-size:34%;
        }
    
       
    
    .horarios{
        color:red;
        background:white;
        width:48%;
    }

    a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: red;
  background-color: transparent;
  text-decoration: underline;
}</style> 
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>SISTEMA REVISIONAL ENEM</title>
	</head>
<body>
   <center> <div class="i">
        <h1>Gramatica</h1>
    </div></center>
    <div class="o"> 
        <table>
            <tr><td><a href="materias.php"><input type="button" value="VOLTAR À MATÉRIAS"><a></td></tr>
        </table>
    </div >
    <div class="r">
    <center>
        <h2>
    <table border=3px>
        <tr>       <td><h1>Data</h1></td>      <td><h1>Material</h1></td>                        </tr>
        <tr>       <td>18/10</td>              <td><a href="gramatica/questoesdegramatica.pdf" download>Questões de Gramática </a></td>                                                                </tr>
        <tr>       <td>18/10</td>              <td><a href="gramatica/gabarito.pdf" download>Gabarito </a></td>                                                                </tr>    
    </table>    

        </h2>
    </center>
    </div>
</body>
</html>